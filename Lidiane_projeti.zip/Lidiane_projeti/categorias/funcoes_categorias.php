<?php

require_once __DIR__.'/../conexao/funcoes_sql.php';

function listaCategorias()
{
    return sqlSelect('categorias', ['*']);
}

function cadastrarCategoria($nome, $icon)
{
    $data_categoria = [
        'nome' => $nome,
        'icon' => $icon,
    ];
    return sqlInsert('categorias',$data_categoria);
}

function atualizarCategoria($id, $nome, $icon)
{
    $data_update = [
        'nome' => $nome,
        'icon' => $icon
    ];
    $where = [['AND', 'id', '=', $id]];

    return sqlUpdate('categorias', $data_update, $where);
}

function deletarCategoria($id)
{
    $where = [['AND', 'id', '=', $id]];
    return sqlDelete('categorias', $where);
}

function getCategoria($id)
{
    return sqlSelect('categorias', ['*'], [['AND', 'id', '=', $id]])[0];
}


