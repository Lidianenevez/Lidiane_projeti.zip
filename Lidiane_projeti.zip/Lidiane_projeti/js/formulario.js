

function verificacao1(){	
	var senha = document.getElementById('password').value;
	var senha2 = document.getElementById('password2').value;
	
	var retorno = false;

	if(senha === '') {

			  document.getElementById('mensagem2').innerHTML = 'Senha fraca'
		    }else if(senha === ''){

		       document.getElementById('mensagem2').innerHTML = 'Este campo não pode ficar vazio'
		     }else if(senha !== senha2 ){ 

			document.getElementById('mensagem2').innerHTML = 'Senhas direferentes'
		  }else{
		  	// swal("Cadastro Realizado com Sucesso!!", {
					// 		      icon: "success",
					// 		    });
		  	retorno = true;
							
		}
			//location.href="php/cadastro.php"
				
				return retorno;

	}
	//<button class="swal-button swal-button--confirm">OK</button>
	

	

/*function login(){	
	var email = document.getElementById('username').value;
	var senha = document.getElementById('password').value;
	var retorno = false;
			if() {

				document.getElementById('mensagem_login2').innerHTML = 'Este campo não pode ficar vazio'
				}else if(){
					
					document.getElementById('mensagem_login2').innerHTML = 'Este campo não pode ficar vazio'

						retorno = true;
				}
			return retorno;
	}
*/
	window.verificacao_pedido = function(){
		var nome = document.getElementById('nome').value;
		var endereco = document.getElementById('endereco').value;
		var cep = document.getElementById('cep').value;
		var celular = document.getElementById('celular').value;
		var pedido = document.getElementById('pedido').value;
		var bairro = document.getElementById('bairro').value;
		var retorno2 = false;
		if(nome.length <= 8){
			document.getElementById('formulario-pedido1').innerHTML = 'Este campo não pode ser menor que 8 caracteres'
		}else if(endereco.indexOf('zerao') == -5){
			document.getElementById('formulario-pedido2').innerHTML = 'Taxa para zerão R$: 3.00'
		}else if(cep <= 8){
			document.getElementById('formulario-pedido3').innerHTML = 'Este campo não pode ser menor que 8 caracteres'
		}else if(celular <= 8){
			document.getElementById('formulario-pedido4').innerHTML = 'Este campo não pode ser menor que 8 caracteres'
		}else if(pedido <= 8){
			document.getElementById('formulario-pedido5').innerHTML = 'Este campo não pode ser menor que 8 caracteres'
		}else{
			retorno2 = true;

		}
		return retorno2;
	}