<?php
require_once __DIR__.'/../funcoes_usuarios.php';

if(isset($_GET['op'])) {

    $opcao = $_GET['op'];

    switch ($opcao) {

        case 'novo':

        $email = $_POST['useremail'];
        $senha = md5($_POST['senha']);
        $nome  = $_POST['username'];
        $cpf  = $_POST['usercpf'];

        if (verificaUsuarioExistente($email, $senha, $cpf)) {
            echo " <script> alert (' Você já está cadastrado! Faça seu login')</script>";
            header('Location: ../../index.php');
        } else {
            //Criar um novo cliente
            if ($cliente = cadastrarCliente($nome, $cpf)){

                //Cria um usuario para o cliente
                if ($usuario = cadastarUsuario($email, $senha, $cliente['id'])) {
                    echo "<script> alert ('Usuario cadastrado com sucesso! Faça seu login')</script>";
                    header('Location: ../../index.php');
                }

            }

        }

        break;
        default:
        header('Location: ../../index.php');
        break;

    }
}