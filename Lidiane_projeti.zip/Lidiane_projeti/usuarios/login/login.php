<?php

require_once __DIR__.'/../funcoes_usuarios.php';

if(isset($_GET['op'])) {

    $opcao = $_GET['op'];

    switch ($opcao) {

        case 'logar':

            $email = $_POST['emaillogin'];
            $senha = md5($_POST['senhalogin']);

            if ($usuario = logar($email, $senha)) {
                criarSessaoUsuario($usuario);
                header('Location: ../../index.php');

            }else{
               echo "Erro ao logar"; 
            }
            break;

        case 'deslogar':
            deslogar();
            header('Location: ../../index.php');
            break;

        default:
        header('Location: ../../index.php');
        break;
    }
}
