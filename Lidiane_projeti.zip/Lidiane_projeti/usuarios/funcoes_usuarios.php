<?php

require_once __DIR__.'/../conexao/funcoes_sql.php';


function verificaUsuarioExistente($email, $senha, $cpf)
{
    $sql_usuario = "
    SELECT
    clientes.cpf, usuarios.email, usuarios.senha
    FROM
    clientes
    LEFT JOIN
    usuarios
    ON
    clientes.id = usuarios.cliente_id
    WHERE
    usuarios.email = ?
    AND
    usuarios.senha = ?
    OR
    clientes.cpf = ?
    ";

    $dados = [
        $email,
        $senha,
        $cpf
    ];

    $usuario = sqlLivre ($sql_usuario, $dados);

    return $usuario;
}


function cadastrarCliente($nome, $cpf)
{
    $data_cliente = [
        'nome' => $nome,
        'cpf' => $cpf,
    ];

    return sqlInsert('clientes',$data_cliente);

}

function cadastarUsuario($email, $senha, $cliente_id)
{
    $data_usuario = [
        'email' => $email,
        'senha' => $senha,
        'cliente_id' => (int) $cliente_id,
    ];

    return sqlInsert('usuarios',$data_usuario);
}

function getUsuario($id)
{
    return sqlSelect('usuarios', ['*'], [['AND', 'id', '=', $id]])[0];
}

function getCliente($id)
{

    return sqlSelect('clientes', ['*'], [['AND', 'id', '=', $id]])[0];

}

function logar($email, $senha)
{
    $usuario =  sqlSelect('usuarios', ['*'], [
        ['AND', 'email', '=', $email],
        ['AND', 'senha', '=', $senha]
    ]);
    return $usuario ? $usuario[0] : $usuario;
}

function criarSessaoUsuario($usuario)
{
    $cliente = getCliente($usuario['cliente_id']);

    $_SESSION['logado'] = true;
    $_SESSION['usuario_atual'] = $usuario;
    $_SESSION['cliente_atual'] = $cliente;

}

function deslogar()
{
    session_destroy();
     $_SESSION['logado'] = false;
}

function isLogado()
{
    return (isset($_SESSION['logado']) && $_SESSION['logado']);
}
