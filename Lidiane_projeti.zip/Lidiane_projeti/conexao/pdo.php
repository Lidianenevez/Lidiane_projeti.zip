<?php

@session_start();

require_once __DIR__.'/config.php';

function conexao() {
	try {

		$pdo = new PDO(DRIVE.':host='.HOST.'; dbname='.DBNAME, DBUSER, DBPASSWORD);

	} catch (PDOException $e){
		echo "Erro ao conectar com MYSQL: " . $e->getMessage();
	}
	return $pdo;
}