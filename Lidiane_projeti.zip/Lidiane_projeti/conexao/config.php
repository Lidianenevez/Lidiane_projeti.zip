<?php
ini_set('display_errors', 1);
function dd($data = null)
{   echo "<pre>";
    var_dump($data);
    die;
}

	define('DRIVE', 'mysql');
	define('HOST', 'localhost');
	define('DBNAME', 'entregafacil_entregafacil');
	define('DBUSER', 'entregafacil_grupo_facil');
	define('DBPASSWORD', 'Facilap2018');
