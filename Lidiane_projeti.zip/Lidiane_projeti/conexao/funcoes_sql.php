<?php
require_once __DIR__.'/pdo.php';

//funcao para executar sql livre
function sqlLivre($sql, $data = [])
{
    $pdo = conexao();

    $stmt = $pdo->prepare($sql);

    $stmt->execute($data);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
//funcao para executar um select no banco
function sqlSelect($table, $columns, $where = [])
{
    $pdo = conexao();

    $colunas = getColumnToSql($columns);
    $where_sql = getWhereToSql($where);
    $data = getDataToWhere($where);

    $sql_select = "
    SELECT
        {$colunas}
    FROM
        {$table}
    WHERE
        1=1
    {$where_sql}
    ";

    $stmt = $pdo->prepare($sql_select);

    $stmt->execute($data);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);

}
//funcao para executar um insert no banco
function sqlInsert($table, $data)
{
    $pdo = conexao();

    $colunas = getColumnToSqlInsert($data);
    $valores = getValuesToSql($data);

    $sql_insert = "
    INSERT INTO
        {$table} ({$colunas})
    VALUES
        ({$valores})
    ";
    $stmt = $pdo->prepare($sql_insert);

    if($stmt->execute(array_values($data))) {
        $last_id = $pdo->query("SELECT LAST_INSERT_ID() as id")->fetch(PDO::FETCH_ASSOC)['id'];
        return sqlSelect($table, ['*'], [['AND', 'id', '=', $last_id]])[0];
    }
    return null;

}

function sqlUpdate($table, $data_set, $where)
{
    $pdo = conexao();

    $valores = getColumnToSqlUpdate($data_set);
    $where_sql = getWhereToSql($where);
    $data_exc = getDataToUpdate($data_set, $where);

    $sql_insert = "
        UPDATE
            {$table}
        SET
            {$valores}
        WHERE
            1=1
        {$where_sql}
    ";
    $stmt = $pdo->prepare($sql_insert);

    if($stmt->execute($data_exc)) {
        return sqlSelect($table, ['*'], $where)[0];
    }
    return null;
}

function sqlDelete($table, $where)
{
    $pdo = conexao();
    $where_sql = getWhereToSql($where);

    $data = getDataToWhere($where);

    $sql_deletar = "
        DELETE FROM
            {$table}
        WHERE
            1=1
            {$where_sql}
        ";
    $stmt = $pdo->prepare($sql_deletar);
    return $stmt->execute($data);
}
/**
* Funcoes de ajustes e montagens de sql
*/
function getColumnToSqlInsert($data)
{
    $pieceString = "";

    foreach (array_keys($data) as $column) {
        $pieceString .= " {$column},";
    }

    return trim(substr_replace($pieceString, '', -1));
}

function getColumnToSqlUpdate($data)
{

    $pieceString = "";


    foreach (array_keys($data) as $column) {
        $pieceString .= " {$column} = ?,";
    }

    return trim(substr_replace($pieceString, '', -1));
}

function getColumnToSql($data)
{
    $pieceString = "";

    foreach ($data as $column) {
        $pieceString .= " {$column},";
    }

    return trim(substr_replace($pieceString, '', -1));
}

function getValuesToSql($data)
{
    $pieceString = "";

    for ($i=0; $i < count($data); $i++) {
        $pieceString .= " ?,";
    }

    return trim(substr_replace($pieceString, '', -1));
}

function getWhereToSql($where)
{
    $pieceString = "";

    foreach ($where as $clausulas) {

        $pieceString .= "{$clausulas[0]} {$clausulas[1]} {$clausulas[2]} ?";

    }

    return trim($pieceString);

}

function getDataToWhere($where)
{
    $data = [];
    foreach ($where as $clausulas) {
        $data[] = $clausulas[3];
    }

    return $data;
}

function getDataToUpdate($set, $where)
{
    $data_set = $set;
    $data_where =[];

    foreach ($where as $clausulas) {
        $data_where[] = $clausulas[3];
    }

    $data = $data_set + $data_where;

    return array_values($data);
}