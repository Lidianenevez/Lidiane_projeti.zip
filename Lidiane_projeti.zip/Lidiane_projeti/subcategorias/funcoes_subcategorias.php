<?php

require_once __DIR__.'/../conexao/funcoes_sql.php';

function listaSubCategorias()
{
    $sql_lista_subcategorias = "
        SELECT
            subcategorias.id, subcategorias.nome, categorias.nome as categoria
        FROM
            subcategorias
        LEFT JOIN
            categorias
        ON
            subcategorias.categoria_id = categorias.id
    ";
    $subcategorias = sqlLivre($sql_lista_subcategorias);

    return $subcategorias;
}

function listaSubCategoriasPorCategoriaId($categoria_id)
{
    return sqlSelect('subcategorias', ['*'], [['AND', 'categoria_id', '=', $categoria_id]]);
}

function cadastrarSubCategoria($nome, $categoria_id)
{
    $data_subcategoria = [
        'nome' => $nome,
        'categoria_id' => $categoria_id,
    ];
    return sqlInsert('subcategorias',$data_subcategoria);
}

function atualizarSubCategoria($id, $nome, $categoria_id)
{
    $data_update = [
        'nome' => $nome,
        'categoria_id' => $categoria_id
    ];
    $where = [['AND', 'id', '=', $id]];

    return sqlUpdate('subcategorias', $data_update, $where);
}

function deletarSubCategoria($id)
{
    $where = [['AND', 'id', '=', $id]];
    return sqlDelete('subcategorias', $where);
}

function getSubCategoria($id)
{
    return sqlSelect('subcategorias', ['*'], [['AND', 'id', '=', $id]])[0];
}


