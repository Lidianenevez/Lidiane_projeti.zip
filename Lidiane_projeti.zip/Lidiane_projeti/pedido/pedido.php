<?php

require_once __DIR__.'/funcoes_pedidios.php';

if(isset($_GET['op'])) {

    $opcao = $_GET['op'];

    switch ($opcao) {

        case 'novo':


            $endereco         = $_POST['endereco'];
            $cep              = $_POST['cep'];
            $bairro           = $_POST['bairro'];
            $telefone         = $_POST['celular'];
            $descricao        = $_POST['pedido'];
            $cliente_id       = $_POST['cliente_id'];
            $subcategoria_id  = $_POST['subcategoria_id'];

            $status_pedido_id = 1;

            if($pedido = cadastrarPedido($endereco, $telefone, $cep, $bairro , $descricao, $cliente_id, $subcategoria_id, $status_pedido_id))
            {
                header('Location:../detalhes.php?id='.$pedido['id']);
            } else {
                echo "Erro ao cadastrar o pedido!";

            }

        break;
        default:
        header('Location: ../index.php');
        break;

    }
}
 // header('Location: ../index.php');