<?php

require_once __DIR__.'/../conexao/funcoes_sql.php';

function cadastrarPedido($endereco, $telefone, $cep, $bairro, $descricao = null, $cliente_id, $subcategoria_id, $status_pedido_id)
{
    $data_pedidio= [
        'endereco'         => $endereco,
        'celular'          => $telefone,
        'cep'              => $cep,
        'bairro'           => $bairro,
        'descricao'        => $descricao,
        'cliente_id'       => $cliente_id,
        'subcategoria_id'  => $subcategoria_id,
        'status_pedido_id' => $status_pedido_id
    ];
    return sqlInsert('pedidos',$data_pedidio);
}

function getPedidio($id)
{
 $sql_pedidio = "
        SELECT
            pedidos.*,
            clientes.nome as cliente,
            subcategorias.nome as subcategoria,
            categorias.nome as categoria,
            status_pedidos.nome as status_pedido
        FROM
            pedidos
        LEFT JOIN
            subcategorias
        ON
            subcategorias.id = pedidos.subcategoria_id
        LEFT JOIN
            categorias
        ON
            categorias.id = subcategorias.categoria_id
        LEFT JOIN
            status_pedidos
        ON
            status_pedidos.id = pedidos.status_pedido_id
        LEFT JOIN
            clientes
        ON
            clientes.id = pedidos.cliente_id
        WHERE
            pedidos.id = ?
        ";
        if ($pedidio = sqlLivre($sql_pedidio, [$id])) {
            return $pedidio[0];
        }
        return null;
}
function getPedidioRestritoUser($id, $cliente_id)
{
    $sql_pedidio = "
        SELECT
            pedidos.*,
            clientes.nome as cliente,
            subcategorias.nome as subcategoria,
            categorias.nome as categoria,
            status_pedidos.nome as status_pedido
        FROM
            pedidos
        LEFT JOIN
            subcategorias
        ON
            subcategorias.id = pedidos.subcategoria_id
        LEFT JOIN
            categorias
        ON
            categorias.id = subcategorias.categoria_id
        LEFT JOIN
            status_pedidos
        ON
            status_pedidos.id = pedidos.status_pedido_id
        LEFT JOIN
            clientes
        ON
            clientes.id = pedidos.cliente_id
        WHERE
            pedidos.id = ?
        AND
            pedidos.cliente_id = ?
        ";
        if ($pedidio = sqlLivre($sql_pedidio, [$id, $cliente_id])) {
            return $pedidio[0];
        }
        return null;

}