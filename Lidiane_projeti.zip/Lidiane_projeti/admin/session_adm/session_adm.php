<?php
session_start();
require_once __DIR__.'/../../usuarios/funcoes_usuarios.php';

if (!isLogado())
	header('Location: index.php');