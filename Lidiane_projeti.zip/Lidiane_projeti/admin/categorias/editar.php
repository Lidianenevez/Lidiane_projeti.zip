<?php
    require_once __DIR__.'/../session_adm/session_adm.php';
    require_once __DIR__.'/../../categorias/funcoes_categorias.php';
    $categoria = getCategoria($_GET['id']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Categorias</title>
     <meta charset="utf-8">
</head>
<body>
    <ul>
        <li>
            <a href="./lista.php">Voltar</a>
        </li>
    </ul>
    <form action="./acoes.php?acao=editar&id=<?=$categoria['id']?>" method="POST">
        <label>
            Nome: <input type="text" name="nome" value="<?=$categoria['nome']?>">
        </label>
        <br>
        <label>
            Icon: <input type="text" name="icon" value="<?=$categoria['icon']?>">
        </label>
        <br>
        <input type="submit">
    </form>
</body>
</html>