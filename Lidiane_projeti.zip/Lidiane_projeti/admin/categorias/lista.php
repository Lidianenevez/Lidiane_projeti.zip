<?php
	require_once __DIR__.'/../session_adm/session_adm.php';
	require_once __DIR__.'/../../categorias/funcoes_categorias.php';

	$lista_categorias = listaCategorias() ? listaCategorias() : [];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Categorias</title>
	 <meta charset="utf-8">
</head>
<body>
	<ul>
		<li>
			<a href="./novo.php">Nova</a>
		</li>
		<li>
			<a href="../index.php">Voltar</a>
		</li>
	</ul>
	<table>
		<tr>
			<th>id</th>
			<th>NOME</th>
			<th>icon</th>
			<th>acoes</th>
		</tr>
		<?php foreach ($lista_categorias as $categoria): ?>
		<tr>
			<td><?=$categoria['id']?></td>
			<td><?=$categoria['nome']?></td>
			<td><?=$categoria['icon']?></td>
			<td>
				<a href="./editar.php?id=<?=$categoria['id']?>">Editar</a>
				<a href="./acoes.php?acao=deletar&id=<?=$categoria['id']?>">Deletar</a>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</body>
</html>