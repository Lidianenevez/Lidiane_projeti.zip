<?php
    require_once __DIR__.'/../session_adm/session_adm.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Categorias</title>
     <meta charset="utf-8">
</head>
<body>
    <ul>
        <li>
            <a href="./lista.php">Voltar</a>
        </li>
    </ul>
    <form action="./acoes.php?acao=novo" method="POST">
        <label>
            Nome: <input type="text" name="nome">
        </label>
        <br>
        <label>
            Icon: <input type="text" name="icon">
        </label>
        <br>
        <input type="submit">
    </form>
</body>
</html>