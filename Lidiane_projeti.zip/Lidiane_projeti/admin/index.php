<?php
	require_once __DIR__.'/session_adm/session_adm.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADM</title>
</head>
<body>

	<ul>
		<li>
            <a href="categorias/lista.php">Categorias</a>
        </li>
        <li>
			<a href="subcategorias/lista.php">Subcategorias</a>
		</li>
	</ul>
</body>
</html>