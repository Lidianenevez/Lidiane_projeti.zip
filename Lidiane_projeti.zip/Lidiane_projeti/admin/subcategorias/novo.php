<?php
require_once __DIR__.'/../session_adm/session_adm.php';
require_once __DIR__.'/../../categorias/funcoes_categorias.php';

$lista_categorias = listaCategorias() ? listaCategorias() : [];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cadastrar Subcategorias</title>
    <meta charset="utf-8">
</head>
<body>
    <ul>
        <li>
            <a href="./lista.php">Voltar</a>
        </li>
    </ul>
    <form action="./acoes.php?acao=novo" method="POST">
        <label>
            Nome: <input type="text" name="nome">
        </label>
        <br>
        <label>
            Categoria:
            <select name="categoria_id">
                <?php foreach ($lista_categorias as $categoria): ?>
                    <option value="<?=$categoria['id']?>"> <?=$categoria['nome']?> </option>
                <?php endforeach; ?>
            </select>
        </label>
        <br>
        <br>
        <input type="submit">
    </form>
</body>
</html>