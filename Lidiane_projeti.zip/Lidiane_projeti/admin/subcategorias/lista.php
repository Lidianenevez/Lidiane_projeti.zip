<?php
	require_once __DIR__.'/../session_adm/session_adm.php';
	require_once __DIR__.'/../../subcategorias/funcoes_subcategorias.php';

	$lista_subcategorias = listaSubCategorias() ? listaSubCategorias() : [];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Categorias</title>
	 <meta charset="utf-8">
</head>
<body>
	<ul>
		<li>
			<a href="./novo.php">Nova</a>
		</li>
		<li>
			<a href="../index.php">Voltar</a>
		</li>
	</ul>
	<table>
		<tr>
			<th>id</th>
			<th>NOME</th>
			<th>Categoria</th>
			<th>acoes</th>
		</tr>
		<?php foreach ($lista_subcategorias as $subcategoria): ?>
		<tr>
			<td><?=$subcategoria['id']?></td>
			<td><?=$subcategoria['nome']?></td>
			<td><?=$subcategoria['categoria']?></td>
			<td>
				<a href="./editar.php?id=<?=$subcategoria['id']?>">Editar</a>
				<a href="./acoes.php?acao=deletar&id=<?=$subcategoria['id']?>">Deletar</a>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</body>
</html>