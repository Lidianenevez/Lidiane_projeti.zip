<?php
    require_once __DIR__.'/../session_adm/session_adm.php';
    require_once __DIR__.'/../../subcategorias/funcoes_subcategorias.php';
    require_once __DIR__.'/../../categorias/funcoes_categorias.php';
    $subcategoria = getSubCategoria($_GET['id']);
    $lista_categorias = listaCategorias() ? listaCategorias() : [];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Categorias</title>
     <meta charset="utf-8">
</head>
<body>
    <ul>
        <li>
            <a href="./lista.php">Voltar</a>
        </li>
    </ul>
    <form action="./acoes.php?acao=editar&id=<?=$categoria['id']?>" method="POST">
        <label>
            Nome: <input type="text" name="nome" value="<?=$subcategoria['nome']?>">
        </label>
        <br>
        <label>
            Categoria:
            <select name="categoria_id">
                <?php foreach ($lista_categorias as $categoria): ?>
                    <?php
                        $selected = ($categoria['id'] == $subcategoria['categoria_id']) ? 'selected' : '';
                     ?>
                    <option value="<?=$categoria['id']?>" <?=$selected?> > <?=$categoria['nome']?> </option>
                <?php endforeach; ?>
            </select>
        </label>
        <br>
        <input type="submit">
    </form>
</body>
</html>