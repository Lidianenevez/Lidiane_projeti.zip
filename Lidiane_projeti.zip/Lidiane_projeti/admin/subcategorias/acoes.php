<?php
    require_once __DIR__.'/../session_adm/session_adm.php';
    require_once __DIR__.'/../../subcategorias/funcoes_subcategorias.php';

    if (isset($_GET['acao'])) {

        switch ($_GET['acao']) {
            case 'novo':
                $nome = $_POST['nome'];
                $categoria_id = $_POST['categoria_id'];

                if ($categoria = cadastrarSubCategoria($nome, $categoria_id)) {
                    echo "Subategoria cadastrada com sucesso!";
                }
                break;
            case 'editar':
                $id = $_GET['id'];
                $nome = $_POST['nome'];
                $icon = $_POST['icon'];

                if ($categoria = atualizarCategoria($id, $nome, $icon)) {
                    echo "Categoria Atualizada";
                }

                # code...
                break;
            case 'deletar':
                  $id = $_GET['id'];
                if (deletarCategoria($id)) {
                    echo "Categoria deletada";
                }

                break;
            default:
                # code...
                break;
        }

    }