<form action="usuarios/login/login.php?op=logar" method="post">
	<div class="row form-group">
		<div class="col-md-12">
			<label for="username">E-mail</label>
			<input type="text" name="emaillogin" class="form-control"  required>
		</div>
	</div>
	<div class="row form-group">
		<div class="col-md-12">
			<label for="password">Senha</label>
			<input type="password" name="senhalogin" class="form-control"  required>
		</div>
	</div>

	<div class="row form-group">

		<div class="col-md-12">
			<input type="submit" class="btn" name="btnlogin" value="Login" >
		</div>
	</div>
</form>	