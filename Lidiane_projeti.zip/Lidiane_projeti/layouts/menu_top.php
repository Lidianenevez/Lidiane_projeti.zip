<nav class="gtco-nav" role="navigation">
    <div class="gtco-container">
        <div class="row">
            <div class="col-sm-4 col-xs-12">
                <div id="gtco-logo"><a href="index.html">Entrega<span style="color: #FFA500;">Fácil</span></a></div>
            </div>
            <div class="col-xs-8 text-right menu-1">
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="pricing.php">QUEM SOMOS</a></li>
                    <li class="has-dropdown"><a href="#">CATEGORIAS</a>
                        <ul class="dropdown">
                            <li><a href="index.php">Alimentos e Bebidas</a></li>
                            <li><a href="index.php">Bebês e Criaças</a></li>
                            <li><a href="index.php">Autopeças</a></li>
                            <li><a href="index.php">Contrução e Reforma</a></li>

                            <li><a href="index.php">Materias de Limpeza</a></li>
                            <li><a href="index.php">Utensílios Domésticos</a></li>
                            <li><a href="index.php">Saúde</a></li>
                            <li><a href="index.php">Papelarias e Livrarias</a></li>

                        </ul>
                    </li>
                    
                    <?php if (isLogado()): ?>
                        <li class="btn-cta"><a href="usuarios/login/login.php?op=deslogar"><span><?=$_SESSION['cliente_atual']['nome']?>: Sair</span></a></li>
                    <?php else: ?>
                        <li class="btn-cta"><a href="#login"><span>Cadastre-se</span></a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

    </div>
</nav>