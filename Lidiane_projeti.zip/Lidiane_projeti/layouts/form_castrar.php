<form action="usuarios/cadastro/cadastro.php?op=novo"  id="form-cadastro" method="post">
	<div class="row form-group">
		<div class="col-md-12">

			<label for="useremail">E-mail</label>
			<input type="text" name="useremail" class="form-control" id="useremail" required>
			
		</div>
	</div>
	<div class="row form-group">
		<div class="col-md-12">
			<label for="username">Nome</label>
			<input type="text" name="username" class="form-control" id="username" >
			
		</div>
	</div>
	<div class="row form-group">
		<div class="col-md-12">
			<label for="usercpf">CPF</label>
			<input type="text" name="usercpf" class="form-control" id="usercpf" >
			
		</div>
	</div>
	<div class="row form-group">
		<div class="col-md-12">
			<label for="password">Senha</label>
			<input type="password" name="senha" class="form-control" id="password">
			<div id="mensagem2"></div>
		</div>
	</div>
	<div class="row form-group">
		<div class="col-md-12">
			<label for="password2">Repita Senha</label>
			<input type="password" name="resenha" class="form-control" id="password2">
			<div id="mensagem2"></div>
		</div>
	</div>
	<div class="row form-group">
		<div class="col-md-12">
			<input type="submit" class="btn" value="cadastrar" name="cadastrar">
		</div>
	</div>
</form>	