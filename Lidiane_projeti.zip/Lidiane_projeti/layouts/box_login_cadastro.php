 <div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight" id="login">
    <div class="form-wrap">
        <div class="tab" >
            <ul class="tab-menu">
                <li class="active gtco-first"><a href="#" data-tab="signup" style="color: #FFA500;">Cadastre-se</a></li>
                <li class="gtco-second"><a href="#" data-tab="login"  style="color: #FFA500;">Login</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-content-inner active" data-content="signup">

                    <?php
                    require __DIR__.'/form_castrar.php';
                    ?>

                </div>

                <div class="tab-content-inner" data-content="login" >
                    <?php
                    require __DIR__.'/form_login.php';
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>