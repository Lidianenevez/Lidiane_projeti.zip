<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Faça seu login primeiro</h3>
        <button type="button" class="close" style="font-size: 50px ; position: absolute; right: 20px; bottom: 280px;" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="usuarios/login/login.php?op=logar" method="post">
  <div class="row form-group">
    <div class="col-md-12">
      <label for="username">E-mail</label>
      <input type="text" name="emaillogin" class="form-control"  required>
    </div>
  </div>
  <div class="row form-group">
    <div class="col-md-12">
      <label for="password">Senha</label>
      <input type="password" name="senhalogin" class="form-control"  required>
    </div>
  </div>

  <div class="row form-group">

    <div class="col-md-12">
      <input type="submit" class="btn" name="btnlogin" value="Login" > ou <a style="color: #000" href="index.php">Cadastre-se</a>
    </div>
  </div>
</form> 
    </div>
  </div>
      </div>
    </div>
  </div>
</div>