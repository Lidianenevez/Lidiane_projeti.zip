<?php
require_once __DIR__.'/../subcategorias/funcoes_subcategorias.php';
$subcategorias = listaSubCategoriasPorCategoriaId($categoria['id']);
?>

<div class="modal"  id="exampleModal<?=$categoria['id']?>" tabindex="2" role="dialog">
    <div class="modal-dialog" role="document">
        <form  method="post" action="./pedido/pedido.php?op=novo">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">FAÇA SEU PEDIDO </h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" style="font-weight: bold; font-size: 30px; position: relative; top: -20px">X</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>SEU NOME</label>
                            <input type="text" name="nome" class="form-control" disabled value="<?=$_SESSION['cliente_atual']['nome']?>">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>ENDEREÇO</label>
                            <input type="text" name="endereco" class="form-control" placeholder="Endereço de Entrega" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>CEP</label>
                            <input type="text" name="cep" class="form-control" placeholder="CEP" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label class="sr-only" for="name">BAIRROS</label>
                                <!--BAIRROS<input type="text" id="bairro" class="form-control" placeholder="" name="bairro">-->
                                BAIRROS <br><select name="bairro" id="bairro" class="form-control" >
                                    <option value="">--</option>
                                    <option value="R$5,00"> Alvorada -> taxa: R$5,00</option>
                                    <option value="R$3,00"> Araxá-> taxa: R$3,00</option>
                                    <option value="R$4,50"> Beirol-> taxa: R$4,50</option>
                                    <option value="R$5,00"> Boné Azul-> taxa: R$5,00</option>
                                    <option value="R$6,00"> Brasil Novo-> taxa: R$6,00</option>
                                    <option value="R$3,00"> Buritizal-> taxa: R$3,00</option>
                                    <option value="R$5,00"> Cabralzinho-> taxa: R$5,00</option>
                                    <option value="R$4,00">Cidade Nova-> taxa: R$4,00</option>
                                    <option value="R$3,00">Congós-> taxa: R$3,00</option>
                                    <option value="R$5,00">Infraero-> taxa: R$5,00</option>
                                    <option value="R$4,00">Jardim Equatorial-> taxa: R$4,00</option>
                                    <option value="R$4,00">Jardim Felicidade-> taxa: R$4,00</option>
                                    <option value="R$5,00">Jesus de Nazaré-> taxa: R$5,00</option>
                                    <option value="R$4,00">Laguinho-> taxa: R$4,00</option>
                                    <option value="R$2,00">Marco Zero -> taxa: R$2,00</option>
                                    <option value="R$5,00">Marabaixo -> taxa: R$5,00</option>
                                    <option value="R$3,00">Nova Esperança-> taxa: R$3,00</option>
                                    <option value="R$3,00">Novo Buritizal -> taxa: R$3,00</option>
                                    <option value="R$5,00">Novo Horizonte-> taxa: R$5,00</option>
                                    <option value="R$4,00">Pacoval-> taxa: R$4,00</option>
                                    <option value="R$4,00">Pedrinhas-> taxa: R$4,00</option>
                                    <option value="R$5,00">Perpétuo Socorro-> taxa: R$5,00</option>
                                    <option value="R$4,50">Santa Inês-> taxa: R$4,50</option>
                                    <option value="R$4,50">Santa Rita-> taxa: R$4,50</option>
                                    <option value="R$5,00">São Lázaro-> taxa: R$5,00</option>
                                    <option value="R$4,50">Trem-> taxa: R$4,50</option>
                                    <option value="R$3,00">Universidade-> taxa: R$3,00</option>
                                    <option value="R$3,00">Zerão->:R$3,00</option>

                                </select>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>CELULAR</label>
                            <input type="text" name="celular" class="form-control" placeholder="Seu número" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>CATEGORIA</label>
                            <input type="text" name="categoria" class="form-control" disabled value="<?=$categoria['nome']?>">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>PEDIDO</label>
                            <select name="subcategoria_id" class="form-control">
                                <?php foreach($subcategorias as $subcategoria): ?>
                                    <option value="<?=$subcategoria['id']?>"><?=$subcategoria['nome']?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>  DESCRIÇÃO DO PEDIDO
                            </label>
                            <textarea name="pedido" id="message" cols="0" rows="0" class="form-control" placeholder="Descreva seu pedido"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="form-group">
                        <input type="submit" value="Enviar" class="btn" name="btn">
                    </div>
                </div>
            </div>
            <input type="hidden" name="cliente_id" value="<?=$_SESSION['cliente_atual']['id']?>">
        </form>
    </div>
</div>