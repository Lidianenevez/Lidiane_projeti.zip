<?php
require_once __DIR__.'/../categorias/funcoes_categorias.php';
$lista_categorias = listaCategorias() ? listaCategorias() : [];
?>
<!-- categorias -->
<div class="row">
    <?php foreach ($lista_categorias as $categoria):
        if (isLogado()) {
            $nomeModal = "#exampleModal{$categoria['id']}";
        } else {
            $nomeModal = "#exampleModal";
        }
        ?>
        <div class="col-md-3 col-sm-6">
            <div class="feature-center animate-box" data-animate-effect="fadeIn">
                <span class="icon">
                    <i class="material-icons">&<?=$categoria['icon']?></i>
                </span>
                <h3 style="color: #FFA500"><?=$categoria['nome']?></h3>
                <button type="button" class="btn " data-toggle="modal" data-target="<?=$nomeModal?>" name="Alimentos" onclick="botao()">Faça seu pedido</button>
            </div>
        </div>

        <!-- modal de pedido-->
        <?php
        if (isLogado()) {

            require __DIR__.'/modal_pedido.php';
        }
    endforeach;
    if (!isLogado()){
        require __DIR__.'/modal_login.php';
    }
    ?>
        <!-- <div class="col-md-3 col-sm-6">
            <div class="feature-center animate-box" data-animate-effect="fadeIn">
                <span class="icon">
                    <i class="material-icons" style="text-decoration:">&#xEB42;</i>
                </span>
                <h3 style="color: #FFA500">Bebês e Crianças</h3>
                <button type="button" class="btn " data-toggle="modal" data-target="#exampleModal" onclick="botao()" name="bebes"> Faça seu pedido</button>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="feature-center animate-box" data-animate-effect="fadeIn">
                <span class="icon">
                    <i class="material-icons" style="text-decoration: none;">&#xE8B8;</i>
                </span>
                <h3 style="color: #FFA500">Autopeças</h3>
                <button type="button" class="btn " data-toggle="modal" data-target="#exampleModal" onclick="botao()" name="autopecas"> Faça seu pedido</button>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="feature-center animate-box" data-animate-effect="fadeIn">
                <span class="icon">
                    <i class="material-icons" style="text-decoration: none;">&#xE869;</i>
                </span>
                <h3 style="color: #FFA500">Construção e Reforma</h3>
                <button type="button" class="btn " data-toggle="modal" data-target="#exampleModal" onclick="botao()" name="construcao"> Faça seu pedido</button>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="feature-center animate-box" data-animate-effect="fadeIn">
                <span class="icon">
                    <i class="material-icons" style="text-decoration: none;">&#xE54A;</i>
                </span>
                <h3 style="color: #FFA500">Materias de Limpeza</h3>
                <button type="button" class="btn " data-toggle="modal" data-target="#exampleModal" onclick="botao()" name="limpeza"> Faça seu pedido</button>
            </div>
        </div>
        <br>
        <div class="col-md-3 col-sm-6">
            <div class="feature-center animate-box" data-animate-effect="fadeIn">
                <span class="icon">
                    <i class="material-icons" style="text-decoration: none;">&#xE16B;</i>
                </span>
                <h3 style="color: #FFA500">Utensílios Domésticos</h3>
                <button type="button" class="btn " data-toggle="modal" data-target="#exampleModal" onclick="botao()" name="utensilios"> Faça seu pedido</button>
            </div>
        </div>
        <br>
        <div class="col-md-3 col-sm-6">
            <div class="feature-center animate-box" data-animate-effect="fadeIn">
                <span class="icon">
                    <i class="material-icons"><a href="" style="text-decoration: none;color: inherit;">&#xE63F;</a></i>
                </span>
                <h3 style="color: #FFA500">Saúde</h3>
                <button type="button" class="btn " data-toggle="modal" data-target="#exampleModal"  onclick="botao()" name="saude"> Faça seu pedido</button>
            </div>
        </div>
        <br>
        <div class="col-md-3 col-sm-6">
            <div class="feature-center animate-box" data-animate-effect="fadeIn">
                <span class="icon">
                    <i class="material-icons" style="text-decoration: none;">&#xE54B;</i>
                </span>
                <h3 style="color: #FFA500">Papelarias e Livrarias</h3>
                <button type="button" class="btn " data-toggle="modal" data-target="#exampleModal" onclick="botao()" name="papelarias"> Faça seu pedido</button>
            </div>
        </div> -->
        <br>

    </div>

